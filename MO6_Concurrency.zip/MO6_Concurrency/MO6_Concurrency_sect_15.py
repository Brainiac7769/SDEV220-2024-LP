import multiprocessing
import math
from random import randint
from time import sleep
from datetime import datetime
 
  
def print_cube(num): 
    """ 
    function to print cube of given num 
    """
    print("Cube: {}".format(num * num * num)) 
  
def print_square(num): 
    """ 
    function to print square of given num 
    """
    print("Square: {}".format(num * num)) 
    
def print_circle_area(radius):
    area = math.pi * radius * radius
    print(f"Circle Area: {area}")   
  
if __name__ == "__main__": 
  
    p1 = multiprocessing.Process(target=print_square, args=(10, )) 
    p2 = multiprocessing.Process(target=print_cube, args=(10, )) 
    p3 = multiprocessing.Process(target=print_circle_area, args=(10,))  
  
    # starting process 1
    p1.start()
    # sleeping a random amount of time between 1 and 5 seconds 
    sleep(randint(1,5))
    # starting process 2  
    p2.start()
    # sleeping a random amount of time between 1 and 5 seconds 
    sleep(randint(1,5))
    # starting process 3
    p3.start()
    # sleeping a random amount of time between 1 and 5 seconds 
    sleep(randint(1,5))
    
    # waiting until process 1 is finished
    p1.join()
    # waiting until process 2 is finished 
    p2.join()
    # waiting until process 3 is finished
    p3.join() 
  
    # all processes finished, determine current time
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    
    # print current time and "Done!"
    print("Current Time:", current_time)
    print("Done!") 