from datetime import datetime

current_date = datetime.now().strftime('%Y-%m-%d')

with open('C:\\Users\\77tha\\today.txt', 'w') as file:
    file.write(current_date) 

with open('C:\\Users\\77tha\\today.txt', 'r') as file:
    today_string = file.read()  

parsed_date = datetime.strptime(today_string, '%Y-%m-%d')

