import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg   # importing needed tools
from matplotlib.figure import Figure
from PIL import Image

class StoreLayout:                                               # Class for layout 
    def __init__(self):
        self.layout = {
            'Bananas': (400, 500),
            'Milk': (300, 100),
            'Socks': (1000, 600),
            'Oil': (2300, 250),
            'Frisbee': (1900, 700),
            'Fertilizer': (2250, 1100),
            'Lipstick': (1900, 700),
            'Cooking Pan': (1600, 600),
            'Computer': (1450, 220),
            'Bread': (400, 800)
        }
        self.entry_doors = {'East Door': (1400, 1200), 'West Door': (420, 1200)}

    def calculate_route(self, items, entry_door):              # supposed to draw a line between chosen items, door etc. for the best route but does not work.
        entry_point = self.entry_doors[entry_door]
        route = []
        for item in items:
            item_position = self.layout[item]
            route.append((item, item_position))
        return route, entry_point

class ItemSelection:                                           # class for item selection
    def __init__(self):
        self.items = ['Bananas', 'Milk', 'Socks', 'Oil', 'Frisbee', 'Fertilizer', 'Lipstick', 'Cooking Pan', 'Computer', 'Bread']
        self.selected_items = []

class GUIApplication:                   #Class to control the GUI
    def __init__(self, root):
        self.root = root
        self.store_layout = StoreLayout()
        self.item_selection = ItemSelection()
        self.setup_ui()
 
    def setup_ui(self):
        self.root.title("Shopping Map")
        self.root.geometry("600x800")

        ttk.Label(self.root, text="First, Select Entry Door:").grid(column=0, row=0, padx=10, pady=10)
        self.entry_door_var = tk.StringVar()
        self.entry_door_combobox = ttk.Combobox(self.root, textvariable=self.entry_door_var, values=list(self.store_layout.entry_doors.keys()))
        self.entry_door_combobox.grid(column=1, row=0, padx=10, pady=10)

        ttk.Label(self.root, text="Next, select Items:").grid(column=0, row=1, padx=10, pady=10, sticky=tk.W)
        self.items_listbox = tk.Listbox(self.root, selectmode=tk.MULTIPLE)
        self.items_listbox.grid(column=1, row=1, padx=10, pady=10, sticky=tk.W+tk.E)
        for item in self.item_selection.items:
            self.items_listbox.insert(tk.END, item)

        ttk.Button(self.root, text="Order Complete", command=self.complete_order).grid(column=1, row=2, padx=10, pady=10, sticky=tk.W+tk.E)

        self.plot_frame = ttk.Frame(self.root)
        self.plot_frame.grid(column=0, row=3, columnspan=2, pady=10)
        self.figure = Figure(figsize=(6, 6), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, self.plot_frame)
        self.canvas.get_tk_widget().pack()
        
    def complete_order(self):
        selected_indices = self.items_listbox.curselection()
        selected_items = [self.item_selection.items[i] for i in selected_indices]
        entry_door = self.entry_door_var.get()
        if not entry_door:
            messagebox.showerror("Error", "Please select an entry door.")
            return
        if not selected_items:
            messagebox.showerror("Error", "Please select at least one item.")
            return
        route, entry_point = self.store_layout.calculate_route(selected_items, entry_door)
        self.plot_on_map(route, entry_point)    

    def plot_on_map(self, route, entry_point):
        
        self.figure.clf()

       
        ax = self.figure.add_subplot(111)
        ax.set_title("Store Image")

                                                                                                # Load the store layout image
        store_image = Image.open("C:/IVY/Spring 2024-1/SDEV 220 Python/final/Store.png")        # Ensure you change the path to the store layout image included in the zip
        ax.imshow(store_image, aspect='auto')

                                                                                                # Plots the item(s) on the map
        for item, position in route:
            ax.scatter(*position, s=100, c='red', marker='o')  
            ax.text(position[0], position[1], item, color='white', fontsize=8, ha='center', va='center')

       
        ax.scatter(*entry_point, s=150, c='red', marker='D')                                           # I use a diamond marker for the entry door selected
        ax.text(entry_point[0], entry_point[1], 'Entry', color='white', fontsize=8, ha='center', va='center')
       
        ax.axis('off')     #turns the "X" and "Y" grid lines off
        self.canvas.draw()
        
    def run(self):
        self.root.mainloop()    

if __name__ == "__main__":
    root = tk.Tk()
    app = GUIApplication(root)
    app.run()
