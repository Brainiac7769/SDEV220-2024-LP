from flask import flask


@app.route('/')
def index():
    return 'Hello!'

@app.route('/drinks')
def get_drinks():
    return {"drinks": "drink data"}

    
