# Lynn Prout - SDEV220 1st 8 weeks Spring 2024
# M04 Programming Assignment- Modules and Databases
# Chapter 16 - 16.8

import sqlite3

connection = sqlite3.connect('books.db')

cursor = connection.cursor()

create_table_query = '''
CREATE TABLE IF NOT EXISTS books (
    title TEXT,
    author TEXT,
    year INTEGER
)
'''

cursor.execute(create_table_query)

connection.commit()

cursor.close()
connection.close()