# Lynn Prout - SDEV220 1st 8 weeks Spring 2024
# M04 Programming Assignment- Modules and Databases
# Chapter 11 - 11.1

def hours():
    print('Open 9-5 daily')
    

    