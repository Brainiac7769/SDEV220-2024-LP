# Lynn Prout - SDEV220 1st 8 weeks Spring 2024
# M04 Programming Assignment- Modules and Databases
# Chapter 16 - 16.8

from sqlalchemy import create_engine, MetaData, Table

engine = create_engine('sqlite:///books.db')

metadata = MetaData()
metadata.reflect(bind=engine)

books_table = metadata.tables['books']

query = books_table.select().order_by(books_table.c.title)

with engine.connect() as connection:
    result = connection.execute(query)
    titles = [row[0] for row in result]

for title in titles:
    print(title)