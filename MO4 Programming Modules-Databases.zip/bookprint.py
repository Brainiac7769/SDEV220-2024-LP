# Lynn Prout - SDEV220 1st 8 weeks Spring 2024
# M04 Programming Assignment- Modules and Databases
# Chapter 16 - 16.8

import csv
import sqlite3

connection = sqlite3.connect('books.db')

cursor = connection.cursor()

with open('books2.csv', 'r') as file:
    csv_reader = csv.DictReader(file)
    for row in csv_reader:
        title = row['title']
        author = row['author']
        year = int(row['year'])

        cursor.execute("INSERT INTO books (title, author, year) VALUES (?, ?, ?)", (title, author, year))

connection.commit()

cursor.close()
connection.close()