# Lynn Prout - SDEV220 1st 8 weeks Spring 2024
# M04 Programming Assignment- Modules and Databases
# Chapter 16 - 16.8

lines = [
    'title,author,year\n',
    'The Weirdstone of Brisingamen,Alan Garner,1960\n',
    'Perdido Street Station,China Miéville,2000\n',
    'Thud!,Terry Pratchett,2005\n',
    'The Spellman Files,Lisa Lutz,2007\n',
    'Small Gods,Terry Pratchett,1992\n'
]

with open('books2.csv', 'w') as file:
    file.writelines(lines)